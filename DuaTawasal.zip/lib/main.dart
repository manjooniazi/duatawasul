import 'package:flutter/material.dart';
import 'page1.dart';
import 'page2.dart';
import 'page3.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    Wakelock.enable();
    return const MaterialApp(
        // remove the debug banner
        debugShowCheckedModeBanner: false,
        title: 'دعائے توسل عربی اردو',
        home: KindaCode());
  }
}

class KindaCode extends StatefulWidget {
  const KindaCode({Key? key}) : super(key: key);

  @override
  State<KindaCode> createState() => _KindaCodeState();
}

class _KindaCodeState extends State<KindaCode> {
  // Declare and Initialize the PageController
  final PageController _pageController =
      PageController(initialPage: 2, viewportFraction: 1);
  int selectedPage = 2;

  @override
  Widget build(BuildContext context) {
    //Wakelock.enable();
    return Scaffold(
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(50.0),
        child: AppBar(
          centerTitle: true,
          title: const Text(
            "  دعائے توسل ",
            style: TextStyle(
                fontSize: 30.0,
                color: Color(0xFFFCFCFC),
                fontWeight: FontWeight.w100,
                fontFamily: "aslam"),
          ),
        ),
      ),
      bottomNavigationBar: SizedBox(
        height: 40,
        child: BottomNavigationBar(
          backgroundColor: Color(0xffbfdeae),
          currentIndex: selectedPage,
          selectedItemColor: Colors.red,
          unselectedItemColor: Colors.black,
          selectedLabelStyle: TextStyle(fontFamily: 'aslam'),
          unselectedLabelStyle: TextStyle(fontFamily: 'aslam'),
          selectedFontSize: 17,
          unselectedFontSize: 14,
          selectedIconTheme: IconThemeData(opacity: 0.0, size: 0),
          unselectedIconTheme: IconThemeData(opacity: 0.0, size: 0),
          items: [
            BottomNavigationBarItem(
                label: "دیگر ایپس", icon: Icon(Icons.pages)),
            BottomNavigationBarItem(
                label: "اردو ترجمہ", icon: Icon(Icons.pages)),
            BottomNavigationBarItem(label: "عربی دعا", icon: Icon(Icons.pages)),
          ],
          onTap: (int index) {
            _pageController.animateToPage(index,
                duration: Duration(microseconds: 1000), curve: Curves.easeIn);
          },
        ),
      ),
      body: PageView(
        controller: _pageController,
        children: [Page1(), Page2(), Page3()],
        onPageChanged: (index) {
          onPageChange(index);
        },
      ),
    );
  }

  // Dispose the PageController
  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  onPageChange(int index) {
    setState(() {
      selectedPage = index;
    });
  }
}
